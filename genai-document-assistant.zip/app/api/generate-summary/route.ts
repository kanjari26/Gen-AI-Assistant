import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { content, apiKey } = await request.json()

    if (!content) {
      return NextResponse.json({ error: "No content provided" }, { status: 400 })
    }

    if (!apiKey) {
      return NextResponse.json({ error: "OpenAI API key is required" }, { status: 400 })
    }

    const client = openai({ apiKey })

    const { text: summary } = await generateText({
      model: client("gpt-4o"),
      system:
        "You are a document summarization expert. Create concise, informative summaries that capture the key points and main themes of documents.",
      prompt: `Please provide a concise summary of the following document content in under 150 words. Focus on the main points, key themes, and important information:

${content}

Summary:`,
      maxTokens: 200,
    })

    return NextResponse.json({ summary })
  } catch (error) {
    console.error("Error generating summary:", error)
    return NextResponse.json({ error: "Failed to generate summary" }, { status: 500 })
  }
}
