import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { question, userAnswer, documentContent, apiKey } = await request.json()

    if (!question || !userAnswer || !documentContent) {
      return NextResponse.json({ error: "Question, user answer, and document content are required" }, { status: 400 })
    }

    if (!apiKey) {
      return NextResponse.json({ error: "OpenAI API key is required" }, { status: 400 })
    }

    const client = openai({ apiKey })

    const { text: evaluationText } = await generateText({
      model: client("gpt-4o"),
      system: `You are an expert evaluator. Assess user answers based on accuracy, completeness, and understanding demonstrated relative to the document content.

EVALUATION CRITERIA:
1. Accuracy: Is the answer factually correct based on the document?
2. Completeness: Does the answer address all aspects of the question?
3. Understanding: Does the answer demonstrate comprehension of the concepts?
4. Evidence: Does the answer reference or align with document content?

SCORING SCALE (0-10):
- 9-10: Excellent - Accurate, complete, shows deep understanding
- 7-8: Good - Mostly accurate and complete, shows good understanding  
- 5-6: Fair - Partially correct, shows basic understanding
- 3-4: Poor - Some correct elements but significant gaps
- 0-2: Very Poor - Mostly incorrect or irrelevant

Provide your evaluation in this format:
SCORE: [number]
EVALUATION: [detailed feedback explaining the score and how to improve]`,
      prompt: `Document Content:
${documentContent}

Question: ${question}

User's Answer: ${userAnswer}

Please evaluate this answer and provide a score (0-10) with detailed feedback:`,
      maxTokens: 400,
    })

    // Parse the evaluation to extract score and feedback
    const lines = evaluationText.split("\n")
    let score = 5 // default score
    let evaluation = evaluationText

    const scoreLine = lines.find((line) => line.toLowerCase().includes("score:"))
    if (scoreLine) {
      const scoreMatch = scoreLine.match(/(\d+)/)
      if (scoreMatch) {
        score = Number.parseInt(scoreMatch[1])
      }
    }

    const evalLine = lines.find((line) => line.toLowerCase().includes("evaluation:"))
    if (evalLine) {
      const evalIndex = lines.indexOf(evalLine)
      evaluation = lines
        .slice(evalIndex)
        .join("\n")
        .replace(/^evaluation:\s*/i, "")
    }

    return NextResponse.json({ evaluation, score })
  } catch (error) {
    console.error("Error evaluating answer:", error)
    return NextResponse.json({ error: "Failed to evaluate answer" }, { status: 500 })
  }
}
