import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    let content = ""

    if (file.type.includes("text")) {
      // Handle TXT files
      content = await file.text()
    } else if (file.type.includes("pdf")) {
      // For PDF files, we'll extract text (simplified approach)
      // In a real implementation, you'd use a PDF parsing library
      const arrayBuffer = await file.arrayBuffer()
      const text = new TextDecoder().decode(arrayBuffer)

      // This is a simplified extraction - in reality you'd use pdf-parse or similar
      content = text.replace(/[^\x20-\x7E\n]/g, " ").trim()

      if (!content || content.length < 50) {
        content =
          "This appears to be a PDF file. For full PDF text extraction, please use a TXT file or implement proper PDF parsing."
      }
    }

    if (!content.trim()) {
      return NextResponse.json({ error: "Could not extract content from file" }, { status: 400 })
    }

    return NextResponse.json({ content })
  } catch (error) {
    console.error("Error processing document:", error)
    return NextResponse.json({ error: "Failed to process document" }, { status: 500 })
  }
}
