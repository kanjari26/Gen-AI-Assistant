import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { question, documentContent, apiKey } = await request.json()

    if (!question || !documentContent) {
      return NextResponse.json({ error: "Question and document content are required" }, { status: 400 })
    }

    if (!apiKey) {
      return NextResponse.json({ error: "OpenAI API key is required" }, { status: 400 })
    }

    const client = openai({ apiKey })

    const { text: answer } = await generateText({
      model: client("gpt-4o"),
      system: `You are a helpful AI assistant that answers questions based strictly on the provided document content. 

IMPORTANT RULES:
1. Only use information that is explicitly stated or can be directly inferred from the document
2. If the document doesn't contain information to answer the question, clearly state this
3. Always provide justification by referencing specific parts of the document
4. Do not use external knowledge or make assumptions beyond what's in the document
5. Structure your response as: [Answer] followed by [Justification based on document content]`,
      prompt: `Document Content:
${documentContent}

Question: ${question}

Please answer the question based solely on the document content provided above. Include justification for your answer by referencing specific parts of the document.`,
      maxTokens: 500,
    })

    return NextResponse.json({ answer })
  } catch (error) {
    console.error("Error answering question:", error)
    return NextResponse.json({ error: "Failed to answer question" }, { status: 500 })
  }
}
