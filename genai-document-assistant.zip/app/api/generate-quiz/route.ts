import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { documentContent, apiKey } = await request.json()

    if (!documentContent) {
      return NextResponse.json({ error: "Document content is required" }, { status: 400 })
    }

    if (!apiKey) {
      return NextResponse.json({ error: "OpenAI API key is required" }, { status: 400 })
    }

    const client = openai({ apiKey })

    const { text: questionsText } = await generateText({
      model: client("gpt-4o"),
      system: `You are an expert quiz generator. Create challenging, logic-based questions that test deep understanding of document content.

REQUIREMENTS:
1. Generate exactly 3 questions
2. Questions should test comprehension, analysis, and critical thinking
3. Questions should be answerable based on the document content
4. Avoid simple factual recall - focus on understanding and reasoning
5. Each question should be on a separate line
6. Do not number the questions`,
      prompt: `Based on the following document content, generate 3 challenging questions that test the reader's understanding and analytical thinking:

${documentContent}

Generate 3 logic-based questions (one per line):`,
      maxTokens: 300,
    })

    const questions = questionsText
      .split("\n")
      .filter((q) => q.trim().length > 0)
      .slice(0, 3)

    return NextResponse.json({ questions })
  } catch (error) {
    console.error("Error generating quiz:", error)
    return NextResponse.json({ error: "Failed to generate quiz" }, { status: 500 })
  }
}
