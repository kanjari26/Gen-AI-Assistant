"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Upload, FileText, MessageCircle, Brain, Loader2, CheckCircle, XCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type InteractionMode = "ask-anything" | "challenge-me" | null
type QuizState = "generating" | "answering" | "results"

interface Question {
  id: number
  question: string
  userAnswer: string
  evaluation: string
  score: number
}

export default function GenAIAssistant() {
  const [file, setFile] = useState<File | null>(null)
  const [documentContent, setDocumentContent] = useState<string>("")
  const [summary, setSummary] = useState<string>("")
  const [mode, setMode] = useState<InteractionMode>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false)
  const [apiKey, setApiKey] = useState<string>("")

  // Ask Anything mode states
  const [question, setQuestion] = useState("")
  const [answer, setAnswer] = useState("")
  const [isAnswering, setIsAnswering] = useState(false)

  // Challenge Me mode states
  const [quizState, setQuizState] = useState<QuizState>("generating")
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [currentAnswer, setCurrentAnswer] = useState("")
  const [isEvaluating, setIsEvaluating] = useState(false)

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0]
    if (!uploadedFile) return

    if (!apiKey.trim()) {
      alert("Please enter your OpenAI API key first")
      return
    }

    if (!uploadedFile.type.includes("pdf") && !uploadedFile.type.includes("text")) {
      alert("Please upload a PDF or TXT file")
      return
    }

    setFile(uploadedFile)
    setIsProcessing(true)

    try {
      const formData = new FormData()
      formData.append("file", uploadedFile)

      const response = await fetch("/api/process-document", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) throw new Error("Failed to process document")

      const { content } = await response.json()
      setDocumentContent(content)

      // Generate summary with API key
      setIsGeneratingSummary(true)
      const summaryResponse = await fetch("/api/generate-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, apiKey }),
      })

      if (summaryResponse.ok) {
        const { summary: generatedSummary } = await summaryResponse.json()
        setSummary(generatedSummary)
      }
    } catch (error) {
      console.error("Error processing document:", error)
      alert("Error processing document. Please try again.")
    } finally {
      setIsProcessing(false)
      setIsGeneratingSummary(false)
    }
  }

  const handleAskQuestion = async () => {
    if (!question.trim() || !documentContent) return

    setIsAnswering(true)
    try {
      const response = await fetch("/api/ask-question", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          documentContent,
          apiKey,
        }),
      })

      if (response.ok) {
        const { answer: generatedAnswer } = await response.json()
        setAnswer(generatedAnswer)
      }
    } catch (error) {
      console.error("Error asking question:", error)
      setAnswer("Sorry, I encountered an error while processing your question.")
    } finally {
      setIsAnswering(false)
    }
  }

  const generateQuizQuestions = async () => {
    if (!documentContent) return

    setQuizState("generating")
    try {
      const response = await fetch("/api/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ documentContent, apiKey }),
      })

      if (response.ok) {
        const { questions: generatedQuestions } = await response.json()
        setQuestions(
          generatedQuestions.map((q: string, index: number) => ({
            id: index + 1,
            question: q,
            userAnswer: "",
            evaluation: "",
            score: 0,
          })),
        )
        setQuizState("answering")
        setCurrentQuestionIndex(0)
      }
    } catch (error) {
      console.error("Error generating quiz:", error)
    }
  }

  const submitQuizAnswer = async () => {
    if (!currentAnswer.trim()) return

    setIsEvaluating(true)
    const currentQuestion = questions[currentQuestionIndex]

    try {
      const response = await fetch("/api/evaluate-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: currentQuestion.question,
          userAnswer: currentAnswer,
          documentContent,
          apiKey,
        }),
      })

      if (response.ok) {
        const { evaluation, score } = await response.json()

        const updatedQuestions = [...questions]
        updatedQuestions[currentQuestionIndex] = {
          ...currentQuestion,
          userAnswer: currentAnswer,
          evaluation,
          score,
        }
        setQuestions(updatedQuestions)

        if (currentQuestionIndex < questions.length - 1) {
          setCurrentQuestionIndex(currentQuestionIndex + 1)
          setCurrentAnswer("")
        } else {
          setQuizState("results")
        }
      }
    } catch (error) {
      console.error("Error evaluating answer:", error)
    } finally {
      setIsEvaluating(false)
    }
  }

  const resetApp = () => {
    setFile(null)
    setDocumentContent("")
    setSummary("")
    setMode(null)
    setQuestion("")
    setAnswer("")
    setQuestions([])
    setCurrentQuestionIndex(0)
    setCurrentAnswer("")
    setQuizState("generating")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">GenAI Document Assistant</h1>
          <p className="text-gray-600">Upload documents and interact with AI-powered analysis</p>
        </div>

        {/* API Key Input */}
        {!apiKey && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">🔑 OpenAI API Key Required</CardTitle>
              <CardDescription>Enter your OpenAI API key to enable AI-powered document analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                  type="password"
                  placeholder="Enter your OpenAI API key..."
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                />
                <div className="text-sm text-gray-600">
                  <p>
                    • Get your API key from{" "}
                    <a
                      href="https://platform.openai.com/api-keys"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      OpenAI Platform
                    </a>
                  </p>
                  <p>• Your key is only stored in your browser session and never saved</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* File Upload */}
        {apiKey && !file && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Document
              </CardTitle>
              <CardDescription>
                Upload a PDF or TXT file to get started with AI-powered document analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
                <Input type="file" accept=".pdf,.txt" onChange={handleFileUpload} className="hidden" id="file-upload" />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-700">Click to upload</p>
                  <p className="text-sm text-gray-500">PDF or TXT files only</p>
                </label>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Processing Status */}
        {isProcessing && (
          <Alert>
            <Loader2 className="h-4 w-4 animate-spin" />
            <AlertDescription>Processing your document...</AlertDescription>
          </Alert>
        )}

        {/* Document Summary */}
        {file && summary && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document Summary
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{file.name}</Badge>
                <Button variant="ghost" size="sm" onClick={resetApp}>
                  Upload New Document
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isGeneratingSummary ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Generating summary...</span>
                </div>
              ) : (
                <p className="text-gray-700 leading-relaxed">{summary}</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Mode Selection */}
        {file && summary && !mode && (
          <Card>
            <CardHeader>
              <CardTitle>Choose Interaction Mode</CardTitle>
              <CardDescription>Select how you'd like to interact with your document</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              <Button
                variant="outline"
                className="h-24 flex-col gap-2 bg-transparent"
                onClick={() => setMode("ask-anything")}
              >
                <MessageCircle className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Ask Anything</div>
                  <div className="text-xs text-gray-500">Free-form questions about your document</div>
                </div>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex-col gap-2 bg-transparent"
                onClick={() => {
                  setMode("challenge-me")
                  generateQuizQuestions()
                }}
              >
                <Brain className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Challenge Me</div>
                  <div className="text-xs text-gray-500">Test your understanding with AI-generated questions</div>
                </div>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Ask Anything Mode */}
        {mode === "ask-anything" && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Ask Anything
              </CardTitle>
              <CardDescription>
                Ask any question about your document and get AI-powered answers with justifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Ask a question about your document..."
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleAskQuestion} disabled={!question.trim() || isAnswering}>
                  {isAnswering ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ask"}
                </Button>
              </div>

              {answer && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Answer:</h4>
                  <p className="text-gray-700 whitespace-pre-wrap">{answer}</p>
                </div>
              )}

              <Button variant="outline" onClick={() => setMode(null)}>
                Back to Mode Selection
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Challenge Me Mode */}
        {mode === "challenge-me" && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Challenge Me
              </CardTitle>
              <CardDescription>
                Test your understanding with AI-generated questions based on your document
              </CardDescription>
            </CardHeader>
            <CardContent>
              {quizState === "generating" && (
                <div className="text-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>Generating challenging questions based on your document...</p>
                </div>
              )}

              {quizState === "answering" && questions.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">
                      Question {currentQuestionIndex + 1} of {questions.length}
                    </Badge>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Question:</h4>
                    <p className="text-gray-700">{questions[currentQuestionIndex]?.question}</p>
                  </div>

                  <Textarea
                    placeholder="Enter your answer..."
                    value={currentAnswer}
                    onChange={(e) => setCurrentAnswer(e.target.value)}
                    className="min-h-24"
                  />

                  <Button onClick={submitQuizAnswer} disabled={!currentAnswer.trim() || isEvaluating}>
                    {isEvaluating ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit Answer"}
                  </Button>
                </div>
              )}

              {quizState === "results" && (
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold">Quiz Results</h3>

                  {questions.map((q, index) => (
                    <div key={q.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Question {index + 1}</Badge>
                        <div className="flex items-center gap-1">
                          {q.score >= 7 ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-500" />
                          )}
                          <span className="text-sm font-medium">Score: {q.score}/10</span>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-600">Question:</h4>
                        <p className="text-gray-700">{q.question}</p>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-600">Your Answer:</h4>
                        <p className="text-gray-700">{q.userAnswer}</p>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-600">Evaluation:</h4>
                        <p className="text-gray-700">{q.evaluation}</p>
                      </div>
                    </div>
                  ))}

                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setQuizState("generating")
                        generateQuizQuestions()
                      }}
                    >
                      Try New Questions
                    </Button>
                    <Button variant="outline" onClick={() => setMode(null)}>
                      Back to Mode Selection
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
